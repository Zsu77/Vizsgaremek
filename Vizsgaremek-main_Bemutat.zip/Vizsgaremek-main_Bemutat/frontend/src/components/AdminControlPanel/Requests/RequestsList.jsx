import { useEffect, useState } from 'react';
import { useUserContext } from '../../useUserContext';
import { useUsersContext } from '../useUsersContext';
import axios from 'axios';
import RequestsListTableRow from './RequestsListTableRow';
import { Button, Collapse } from '@mantine/core';
import { parse, isAfter } from 'date-fns';

export default function RequestsList() {
  const { user } = useUserContext();
  const { users, refreshAllUsers } = useUsersContext();
  const [opened, setOpen] = useState(false);
  const [showAllRequests, setShowAllRequests] = useState(false);
  const { username } = user;

  useEffect(() => {
    if (!users) refreshAllUsers();
    checkNoRequests();
  }, [users]);

  const toggleStatus = async (e, employeeID, dateID) => {
    e.preventDefault();
    await axios.post('/toggle-request-status', {
      dateID,
      employeeID,
      approverUsername: username,
    });
  };

  const blockRequests = (user, date, functional = false) => {
    if (functional) {
      return (
        <RequestsListTableRow
          key={date._id}
          name={user.username}
          comment={date.comment}
          date={date.date}
          status={date.approved}
          onClick={async (e) => {
            await toggleStatus(e, user._id, date._id);
            await refreshAllUsers();
          }}
        />
      );
    } else {
      console.log(date.username + ' ' + date.date + ' ' + date.approvedBy);
      return (
        <RequestsListTableRow
          key={date._id}
          name={user.username}
          comment={date.comment}
          date={date.date}
          status={date.approved}
          approvedBy={date.approvedBy}
        />
      );
    }
  };

  const checkNoRequests = async () => {
    if (users) {
      for (let i = 0; i < users.length; i++) {
        if (users[i].blockedDates.length > 0) {
          setShowAllRequests(true);
          break;
        }
      }
    }
  };

  return (
    <>
      <div className="w-11/12 mx-auto my-5 md:w-5/6 lg:w-4/6">
        <div className="pb-6 border border-gray-200 rounded-lg">
          <div className="flex items-center justify-between px-6 py-3 border-b border-gray-200">
            <p className="text-lg font-semibold leading-tight text-gray-800 lg:text-xl">
              Manage Requests
            </p>
          </div>
          <div className="px-4 pt-4">
            <table className="w-full">
              <tbody>
                {users
                  ? users.map((user) =>
                      user.blockedDates.map((date) => {
                        const parsedDate = parse(date.date, 'dd-MM-yyyy', new Date());
                        if (isAfter(parsedDate, new Date())) {
                          const functional = true;
                          return blockRequests(user, date, functional);
                        }
                      })
                    )
                  : null}
              </tbody>
            </table>

            {showAllRequests && (
              <div className="flex justify-center mt-5">
                <Button className="text-lg bg-gray-600" onClick={() => setOpen((o) => !o)}>
                  View All
                </Button>
              </div>
            )}

            <Collapse in={opened}>
              <table className="w-full mt-2">
                <tbody>
                  {users
                    ? users.map((user) =>
                        user.blockedDates.map((date) => blockRequests(user, date))
                      )
                    : null}
                </tbody>
              </table>
            </Collapse>

            {!showAllRequests && (
              <h1 className="text-2xl font-medium text-center my-28 text-slate-800">
                No date block requests
              </h1>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
