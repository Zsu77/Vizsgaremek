import UserInfoModal from './UserInfoModal';

export default UserInfoModal;
