import ScheduleHistory from './ScheduleHistory';

export default ScheduleHistory;
