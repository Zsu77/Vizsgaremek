import ScheduleHistoryModal from './ScheduleHistoryModal';

export default ScheduleHistoryModal;
