import SchedulePage from './SchedulePage';

export default SchedulePage;
