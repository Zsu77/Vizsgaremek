import CreateUserModal from './CreateUserModal';

export default CreateUserModal;
