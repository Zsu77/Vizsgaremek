import WeekSchedule from './WeekSchedule';

export default WeekSchedule;
